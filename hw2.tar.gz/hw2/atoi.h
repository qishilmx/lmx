/**
 * @Author: qlc
 * @Date:   2018-10-20T19:26:36+08:00
 * @Email:  qlcx@tom.com
 * @Filename: atoi.h
 * @Last modified by:   qlc
 * @Last modified time: 2018-10-21T13:50:04+08:00
 * @License: GPL
 */
#ifndef __MY_ATOI_H_
#define __MY_ATOI_H_

int my_atoi(const char *, int len);

void str_rts(char *);

#endif
